// ============================================================
//  MineStore Bot — продажа сборок серверов Minecraft в Telegram
//  Стек: Node.js + Telegraf
//  Деплой: Railway
// ============================================================

const { Telegraf, Markup } = require('telegraf');
require('dotenv').config();

const BOT_TOKEN = process.env.BOT_TOKEN;
const PROVIDER_TOKEN = process.env.PROVIDER_TOKEN; // токен платёжного провайдера Telegram (ЮKassa/CloudPayments и т.д.)
const ADMIN_ID = process.env.ADMIN_ID; // ваш telegram user id, для уведомлений о заказах
const CURRENCY = process.env.CURRENCY || 'RUB';

if (!BOT_TOKEN) {
  console.error('Ошибка: не задан BOT_TOKEN в переменных окружения.');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

// ============================================================
//  Каталог сборок (легко редактировать / расширять)
//  price указывается в РУБЛЯХ (конвертация в копейки — автоматом)
// ============================================================
const PRODUCTS = [
  {
    id: 'funtime',
    name: 'FunTime-style Сборка',
    price: 2500,
    desc:
      'Развлекательный сервер с мини-играми, экономикой и системой кланов.\n' +
      '• 10+ мини-игр\n• Кастомная экономика\n• Античит настроен\n• Готовая панель донат-магазина',
    fileLink: 'https://example.com/downloads/funtime.zip', // ссылка на архив сборки (замените на свою)
  },
  {
    id: 'reallyworld',
    name: 'ReallyWorld-style Сборка',
    price: 2900,
    desc:
      'RPG-сервер с прокачкой, кастомными предметами и квестами.\n' +
      '• Система прокачки\n• Кастомные ресурспаки\n• Квесты и сюжет\n• Кланы и территории',
    fileLink: 'https://example.com/downloads/reallyworld.zip',
  },
  {
    id: 'skyblock',
    name: 'SkyBlock Сборка',
    price: 1800,
    desc:
      'Классический SkyBlock с островами, апгрейдами и рейтингом игроков.\n' +
      '• Генератор островов\n• Система рейтинга\n• Магазин ресурсов\n• Ивенты',
    fileLink: 'https://example.com/downloads/skyblock.zip',
  },
  {
    id: 'pvpfaction',
    name: 'PvP Faction Сборка',
    price: 2200,
    desc:
      'Жёсткий PvP-сервер с фракциями, войнами за территорию и рейдами баз.\n' +
      '• Система фракций\n• Рейды и захват баз\n• Кастомный крафт\n• Баланс PvP',
    fileLink: 'https://example.com/downloads/pvpfaction.zip',
  },
  {
    id: 'vanillaplus',
    name: 'Ванильная+ Сборка',
    price: 1200,
    desc:
      'Мягкая модерация, лёгкие улучшения ванильного геймплея.\n' +
      '• Кастомная генерация мира\n• Защита территории\n• Телепорты и тимчаты\n• Лёгкий античит',
    fileLink: 'https://example.com/downloads/vanillaplus.zip',
  },
  {
    id: 'techserver',
    name: 'Технический сервер (Tech)',
    price: 2600,
    desc:
      'Сборка с модами на автоматизацию и технику.\n' +
      '• Моды автоматизации\n• Оптимизация TPS\n• Защита машин\n• Гайд по установке',
    fileLink: 'https://example.com/downloads/techserver.zip',
  },
];

function findProduct(id) {
  return PRODUCTS.find((p) => p.id === id);
}

// ============================================================
//  /start — приветствие + главное меню
// ============================================================
bot.start((ctx) => {
  ctx.reply(
    `👋 Добро пожаловать в MineStore!\n\n` +
      `Здесь можно купить готовые сборки серверов Minecraft под ключ: плагины, конфиги, экономика — всё уже настроено.\n\n` +
      `Нажмите «Каталог», чтобы посмотреть доступные сборки.`,
    Markup.inlineKeyboard([[Markup.button.callback('🛒 Каталог', 'catalog')]])
  );
});

bot.command('catalog', (ctx) => sendCatalog(ctx));

function sendCatalog(ctx) {
  const buttons = PRODUCTS.map((p) => [
    Markup.button.callback(`${p.name} — ${p.price} ₽`, `view_${p.id}`),
  ]);
  ctx.reply('📦 Доступные сборки серверов:', Markup.inlineKeyboard(buttons));
}

bot.action('catalog', (ctx) => {
  ctx.answerCbQuery();
  sendCatalog(ctx);
});

// ============================================================
//  Карточка товара
// ============================================================
bot.action(/view_(.+)/, (ctx) => {
  ctx.answerCbQuery();
  const product = findProduct(ctx.match[1]);
  if (!product) return ctx.reply('Товар не найден.');

  ctx.reply(
    `🎮 *${product.name}*\n\n${product.desc}\n\n💰 Цена: *${product.price} ₽*`,
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('💳 Купить', `buy_${product.id}`)],
        [Markup.button.callback('⬅️ Назад к каталогу', 'catalog')],
      ]),
    }
  );
});

// ============================================================
//  Оплата через Telegram Payments (sendInvoice)
//  Требует PROVIDER_TOKEN от платёжного провайдера,
//  подключённого через @BotFather -> Payments.
// ============================================================
bot.action(/buy_(.+)/, async (ctx) => {
  ctx.answerCbQuery();
  const product = findProduct(ctx.match[1]);
  if (!product) return ctx.reply('Товар не найден.');

  if (!PROVIDER_TOKEN) {
    // Резервный сценарий: без подключённого платёжного провайдера —
    // оформляем заявку вручную (админ подтверждает оплату сам).
    await ctx.reply(
      `Вы выбрали: *${product.name}* (${product.price} ₽)\n\n` +
        `Онлайн-оплата пока не подключена. Для покупки свяжитесь с администратором — он вышлет реквизиты и после оплаты пришлёт архив сборки.`,
      { parse_mode: 'Markdown' }
    );
    if (ADMIN_ID) {
      bot.telegram.sendMessage(
        ADMIN_ID,
        `🔔 Новый запрос на покупку!\nТовар: ${product.name}\nЦена: ${product.price} ₽\nПокупатель: @${ctx.from.username || ctx.from.id}`
      );
    }
    return;
  }

  try {
    await ctx.replyWithInvoice({
      title: product.name,
      description: product.desc,
      payload: `order_${product.id}_${ctx.from.id}_${Date.now()}`,
      provider_token: PROVIDER_TOKEN,
      currency: CURRENCY,
      prices: [{ label: product.name, amount: product.price * 100 }], // в минимальных единицах валюты (копейки)
      start_parameter: `buy_${product.id}`,
    });
  } catch (err) {
    console.error('Ошибка при создании счёта:', err);
    ctx.reply('Не удалось создать счёт на оплату. Попробуйте позже или напишите администратору.');
  }
});

// Подтверждение перед оплатой (обязательный шаг Telegram Payments)
bot.on('pre_checkout_query', (ctx) => {
  ctx.answerPreCheckoutQuery(true).catch((err) => console.error(err));
});

// Успешная оплата — выдаём товар
bot.on('message', async (ctx, next) => {
  if (ctx.message && ctx.message.successful_payment) {
    const payload = ctx.message.successful_payment.invoice_payload || '';
    const productId = payload.split('_')[1];
    const product = findProduct(productId);

    await ctx.reply(
      `✅ Оплата прошла успешно!\n\n` +
        (product
          ? `Ваша сборка: *${product.name}*\n📥 Скачать: ${product.fileLink}\n\nИнструкция по установке будет отправлена отдельным сообщением. Если возникнут вопросы — пишите в поддержку.`
          : `Спасибо за покупку! Мы свяжемся с вами для передачи файлов.`),
      { parse_mode: 'Markdown' }
    );

    if (ADMIN_ID) {
      bot.telegram.sendMessage(
        ADMIN_ID,
        `💰 Оплачен заказ!\nТовар: ${product ? product.name : productId}\nПокупатель: @${ctx.from.username || ctx.from.id}`
      );
    }
    return;
  }
  return next();
});

// ============================================================
//  Поддержка
// ============================================================
bot.command('support', (ctx) => {
  ctx.reply('По всем вопросам пишите: @your_support_username');
});

// ============================================================
//  Запуск
// ============================================================
bot.launch().then(() => console.log('Бот запущен ✅'));

// Корректное завершение работы (важно для Railway)
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
